
# Sales Performance Dashboard

## 📊 Project Overview

An end-to-end sales performance and revenue analysis project using
Python, SQL, Excel and business intelligence techniques.

The project analyzes retail transaction data to understand revenue,
profitability, customer behavior, product performance and regional trends.

## 🎯 Business Objectives

- Track total revenue and profit
- Analyze monthly sales trends
- Calculate MoM revenue growth
- Measure average order value
- Compare regional performance
- Analyze category and sub-category profitability
- Identify top-performing products
- Identify loss-making products
- Analyze discount and profitability relationships
- Generate actionable business insights

## 🛠️ Technologies Used

- Python
- Pandas
- NumPy
- Matplotlib
- SQL
- SQLite
- Excel
- Power BI-ready data model

## 📁 Project Structure

- `data/` — cleaned and analytical datasets
- `notebooks/` — Python analysis
- `sql/` — SQL queries and database
- `excel/` — Excel analytical workbook
- `dashboard/` — dashboard assets
- `screenshots/` — project visuals

## 📈 Key KPIs

- Total Revenue
- Total Profit
- Profit Margin
- Total Orders
- Total Customers
- Total Quantity
- Average Order Value
- Month-over-Month Revenue Growth
- Month-over-Month Profit Growth

## 🔍 Analysis Performed

### Sales Analysis
Monthly revenue and profit trends were analyzed to identify periods
of stronger and weaker performance.

### Regional Analysis
Revenue, profit, order volume and profitability were compared across
regions.

### Product Analysis
Products and sub-categories were ranked by revenue and profit to
identify high-performing and loss-making products.

### Customer Analysis
Customer-level revenue, profit and order activity were analyzed to
identify high-value customers.

### Discount Analysis
Discount levels were compared with revenue and profitability to
investigate their relationship with profit performance.

## 💡 Business Insights

Insights are derived from the actual dataset after completing the
analysis and are documented with supporting metrics.

## 👩‍💻 Skills Demonstrated

Python | Pandas | SQL | Excel | Data Cleaning | EDA |
KPI Development | Business Analytics | Data Visualization |
Profitability Analysis | Customer Analysis | Product Analysis
